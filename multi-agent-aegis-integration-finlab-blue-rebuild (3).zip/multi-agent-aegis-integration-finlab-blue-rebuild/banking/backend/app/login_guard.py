"""Fixed-window login guard for the bank's single Uvicorn worker."""
from collections import OrderedDict
from contextlib import contextmanager
from math import ceil
from threading import Lock
from time import monotonic

from fastapi import HTTPException

FAILED_ATTEMPTS = 5
WINDOW_SECONDS = 60


class LoginGuard:
    def __init__(self, clock=monotonic):
        self.clock = clock
        # Serialize checks on the same identity while allowing other logins in parallel.
        self.shards = [(Lock(), OrderedDict()) for _ in range(64)]

    @contextmanager
    def attempt(self, request, identity):
        request.state.required_role = 'LOGIN'
        key = (request.url.path, identity)
        lock, failures = self.shards[hash(key) % len(self.shards)]
        with lock:
            now = self.clock()
            # Entries are inserted in expiry order; updates keep the original deadline.
            while failures and next(iter(failures.values()))[1] <= now:
                failures.popitem(last=False)
            count, deadline = failures.get(key, (0, now + WINDOW_SECONDS))
            full = count == 0 and len(failures) >= 160
            if full or count >= FAILED_ATTEMPTS:
                retry_at = next(iter(failures.values()))[1] if full else deadline
                request.state.login_decision = 'rate_limited_backend'
                raise HTTPException(429, '로그인 시도 제한 시간 이후 다시 시도하세요.',
                                    headers={'Retry-After': str(max(1, ceil(retry_at - now)))})
            try:
                yield
            except HTTPException as exc:
                if exc.status_code == 401:
                    failures[key] = (count + 1, deadline)
                    request.state.login_decision = 'denied'
                raise
            else:
                failures.pop(key, None)
                request.state.login_decision = 'allowed'
