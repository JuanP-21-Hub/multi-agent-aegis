from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Thread
import unittest
from unittest.mock import patch
import lab
from red.run_red import main, local_url

class RedTests(unittest.TestCase):
    def setUp(self):
        self.state = state = {'users': {}, 'fails': {}, 'accounts': {}, 'calls': [], 'mode': 'fixed', 'audit': True, 'broken': False}
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args): pass
            def do_GET(self): self.api()
            def do_POST(self): self.api()
            def api(self):
                body = json.loads(self.rfile.read(int(self.headers['Content-Length']))) if self.headers.get('Content-Length') else None
                path, token = self.path, self.headers.get('Authorization', '')
                state['calls'].append((path, body, token))
                code, data = 200, {}
                if path == '/api/health/db': data = {'status': 'ok'}
                elif path == '/api/customers/signup':
                    uid = len(state['users']) + 1
                    state['users'][body['login_id']] = {**body, 'id': uid}
                    code, data = 201, {'customer_id': uid}
                elif path == '/api/auth/customer/login':
                    user = state['users'][body['login_id']]
                    if body['password'] == user['password']: data = {'access_token': 'secret-token-' + str(user['id'])}
                    else:
                        count = state['fails'].get(body['login_id'], 0) + 1
                        state['fails'][body['login_id']] = count
                        code = 429 if count > 5 else 401
                elif path == '/api/staff/customers': code = 403 if token else 401
                elif path.startswith('/api/customers/'):
                    code = 403 if state['mode'] == 'fixed' else 200
                    data = {'customer_id': int(path.rsplit('/', 1)[1])}
                elif path == '/api/accounts':
                    aid = len(state['accounts']) + 1
                    state['accounts'][aid] = token
                    code, data = 201, {'account_id': aid}
                elif path == '/api/transfers': code = 403 if state['accounts'][body['from_account']] != token else 201
                else: code = 404
                if state['broken']: code = 503
                self.send_response(code)
                self.send_header('Content-Type', 'application/json')
                if state['audit']: self.send_header('X-Audit-Persisted', 'true')
                self.send_header('X-Request-ID', str(len(state['calls'])))
                self.end_headers()
                self.wfile.write(json.dumps(data).encode())
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.thread = Thread(target=self.server.serve_forever, daemon=True)
        self.thread.start()
        self.temp = TemporaryDirectory()
        self.url = f'http://127.0.0.1:{self.server.server_port}'

    def tearDown(self):
        self.server.shutdown()
        self.server.server_close()
        self.thread.join()
        self.temp.cleanup()

    def execute(self, scenario='all'):
        code = main(['--base-url', self.url, '--report-dir', self.temp.name, '--scenario', scenario])
        report = next(Path(self.temp.name).glob('*.json')).read_text()
        return code, json.loads(report), report + next(Path(self.temp.name).glob('*.html')).read_text()

    def test_all_real_http_and_secret_redaction(self):
        code, data, text = self.execute()
        self.assertEqual(code, 0)
        self.assertEqual(len(data['requests']), 16)
        self.assertEqual([r['outcome'] for r in data['results']], ['rate_limited', 'blocked', 'blocked', 'blocked'])
        self.assertFalse(data['blue_executed'])
        self.assertTrue(all(e['audit_persisted'] for e in data['requests']))
        for user in self.state['users'].values(): self.assertNotIn(user['password'], text)
        self.assertNotIn('secret-token-', text)
        self.assertEqual(len(self.state['users']), 2)
        self.assertEqual(len(self.state['accounts']), 2)

    def test_vulnerable_idor(self):
        self.state['mode'] = 'vulnerable'
        code, data, _ = self.execute('idor')
        self.assertEqual(code, 0)
        self.assertEqual(data['results'][0]['outcome'], 'allowed')

    def test_missing_audit(self):
        self.state['audit'] = False
        self.assertEqual(self.execute('staff_access')[0], 2)

    def test_partial_report_on_setup_failure(self):
        self.state['broken'] = True
        code, data, _ = self.execute()
        self.assertEqual(code, 2)
        self.assertFalse(data['completed'])
        self.assertEqual(len(self.state['calls']), 1)
        self.assertEqual(data['results'], [])

    def test_target_validation(self):
        for url in ['https://example.com:8081', 'http://127.0.0.1:8081/api', 'http://127.0.0.1:8081?x=y', 'http://u:p@127.0.0.1:8081', 'http://0.0.0.0:8081', 'http://127.0.0.1']:
            with self.subTest(url=url), self.assertRaises(ValueError): local_url(url)

    def test_compose_port_dispatch(self):
        with patch.object(lab.subprocess, 'run') as run, patch('red.run_red.main', return_value=0) as red, patch.object(lab, 'export_audit') as export:
            run.return_value.stdout = '127.0.0.1:8182\n'
            self.assertEqual(lab.main(['-p', 'existing', 'red', '--scenario', 'staff_access']), 0)
            self.assertEqual(run.call_args.args[0], ['docker', 'compose', '-p', 'existing', '-f', 'compose.yaml', 'port', 'web', '80'])
            self.assertEqual(red.call_args.args[0][:4], ['--base-url', 'http://127.0.0.1:8182', '--scenario', 'staff_access'])
            export.assert_not_called()

    def test_explicit_url_without_docker_or_blue(self):
        with patch.object(lab.subprocess, 'run') as run, patch('red.run_red.main', return_value=0), patch.object(lab, 'export_audit') as export:
            self.assertEqual(lab.main(['red', '--base-url', self.url]), 0)
            run.assert_not_called()
            export.assert_not_called()

if __name__ == '__main__': unittest.main()
