"""Python scenario runner for the local FinLab bank."""
