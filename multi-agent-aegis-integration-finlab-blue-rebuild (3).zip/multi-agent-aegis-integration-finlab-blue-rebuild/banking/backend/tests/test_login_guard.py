import unittest
from concurrent.futures import ThreadPoolExecutor

from fastapi import HTTPException, Request

from app.login_guard import LoginGuard


class LoginGuardTests(unittest.TestCase):
    def setUp(self):
        self.now = 0
        self.guard = LoginGuard(clock=lambda: self.now)

    def decision(self, status=401, identity='demo', role='customer'):
        request = Request({'type': 'http', 'headers': [], 'path': f'/api/auth/{role}/login'})
        try:
            with self.guard.attempt(request, identity):
                if status != 200:
                    raise HTTPException(status)
        except HTTPException as exc:
            return exc.status_code, getattr(request.state, 'login_decision', None), exc.headers
        return 200, request.state.login_decision, None

    def test_window_and_retry_after(self):
        for _ in range(5):
            self.assertEqual(self.decision()[:2], (401, 'denied'))
        self.now = 12
        self.assertEqual(self.decision(), (429, 'rate_limited_backend', {'Retry-After': '48'}))
        self.now = 60
        self.assertEqual(self.decision(status=200)[:2], (200, 'allowed'))

    def test_accounts_and_login_routes_are_independent(self):
        for _ in range(5):
            self.decision()
        self.assertEqual(self.decision(identity='other')[0], 401)
        self.assertEqual(self.decision(role='staff')[0], 401)
        self.assertEqual(self.decision()[0], 429)

    def test_only_failures_count_and_success_resets(self):
        for _ in range(4):
            self.decision()
        self.assertEqual(self.decision(status=503)[:2], (503, None))
        self.assertEqual(self.decision(status=200)[:2], (200, 'allowed'))
        self.assertEqual([self.decision()[0] for _ in range(6)], [401] * 5 + [429])

    def test_overlapping_attempts_share_one_budget(self):
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(lambda _: self.decision()[0], range(12)))
        self.assertEqual(sorted(results), [401] * 5 + [429] * 7)
