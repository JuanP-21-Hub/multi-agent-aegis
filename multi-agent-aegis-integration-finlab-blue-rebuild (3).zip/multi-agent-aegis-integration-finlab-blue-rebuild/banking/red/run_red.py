"""Send bounded Python scenarios to the local FinLab bank; no LLM required."""
import argparse
from datetime import datetime, timezone
import html
import ipaddress
import json
from pathlib import Path
import secrets
import sys
import urllib.error
import urllib.parse
import urllib.request
from uuid import uuid4

SCENARIOS = ('login_failures', 'staff_access', 'idor', 'transfer')
LABELS = {'login_failures': '로그인 연속 실패', 'staff_access': '직원 API 접근',
          'idor': '다른 테스트 고객 조회', 'transfer': '다른 테스트 고객 계좌로 송금 요청'}


def local_url(value):
    parsed = urllib.parse.urlsplit(value)
    try:
        local = parsed.hostname == 'localhost' or ipaddress.ip_address(parsed.hostname).is_loopback
    except ValueError:
        local = False
    if (parsed.scheme != 'http' or not local or parsed.username or parsed.password
            or parsed.path not in ('', '/') or parsed.query or parsed.fragment):
        raise ValueError('은행 주소는 http://127.0.0.1:포트 형식의 로컬 주소를 사용하세요.')
    if parsed.port is None:
        raise ValueError('은행 포트를 지정하세요.')
    return value.rstrip('/')


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class Runner:
    def __init__(self, base_url):
        self.base_url = local_url(base_url)
        self.opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
        self.events = []
        self.results = []
        self.stage = 'setup'

    def call(self, path, body=None, token=None):
        headers = {'Content-Type': 'application/json'}
        if token:
            headers['Authorization'] = 'Bearer ' + token
        request = urllib.request.Request(self.base_url + path, headers=headers,
            data=json.dumps(body).encode('utf-8') if body is not None else None)
        try:
            response = self.opener.open(request, timeout=15)
        except urllib.error.HTTPError as error:
            response = error
        except (urllib.error.URLError, TimeoutError, OSError) as error:
            raise ValueError('은행 연결 실패. Docker와 은행 주소를 확인하세요.') from error
        with response:
            status = response.code
            event = {'timestamp': datetime.now(timezone.utc).isoformat(), 'scenario': self.stage,
                     'method': request.get_method(), 'path': path, 'status': status,
                     'request_id': response.headers.get('X-Request-ID', ''),
                     'audit_persisted': response.headers.get('X-Audit-Persisted') == 'true'}
            self.events.append(event)
            raw = response.read(1024 * 1024 + 1)
        if len(raw) > 1024 * 1024:
            raise ValueError('은행 응답 크기가 예상 범위를 넘었습니다.')
        try:
            data = json.loads(raw)
        except (ValueError, UnicodeError) as error:
            raise ValueError(f'{path}: HTTP {status}, 은행 JSON 응답이 아닙니다.') from error
        print(f'[{self.stage}] {request.get_method()} {path} -> {status}', flush=True)
        return status, data

    def expect(self, path, body=None, token=None, status=200):
        actual, data = self.call(path, body, token)
        if actual != status:
            raise ValueError(f'준비 실패: {path} HTTP {actual} (예상 {status})')
        if not isinstance(data, dict):
            raise ValueError(f'준비 실패: {path} 응답 형식 오류')
        return data

    def customer(self):
        login = {'login_id': 'red_' + secrets.token_hex(8), 'password': secrets.token_urlsafe(24)}
        data = self.expect('/api/customers/signup',
            {**login, 'full_name': '레드 자동 실습', 'rrn': 'TEST-RRN-000000'}, status=201)
        cid = data.get('customer_id')
        if type(cid) is not int or cid <= 0:
            raise ValueError('회원가입 응답에 고객 ID가 없습니다.')
        auth = self.expect('/api/auth/customer/login', login)
        token = auth.get('access_token')
        if not isinstance(token, str) or not token:
            raise ValueError('로그인 응답에 인증 토큰이 없습니다.')
        return login, cid, token

    def result(self, name, statuses, outcome, note):
        self.results.append({'scenario': name, 'statuses': statuses, 'outcome': outcome, 'note': note})
        print(f'{LABELS[name]}: {outcome} — {note}', flush=True)

    def execute(self, scenario):
        self.expect('/api/health/db')
        login, _, token = self.customer()
        selected = SCENARIOS if scenario == 'all' else (scenario,)
        target_id = target_token = None
        if any(s in selected for s in ('idor', 'transfer')):
            _, target_id, target_token = self.customer()
        for name in selected:
            self.stage = name
            if name == 'login_failures':
                statuses = [self.call('/api/auth/customer/login',
                    {'login_id': login['login_id'], 'password': 'wrong_' + secrets.token_hex(16)})[0]
                    for _ in range(6)]
                ok = statuses == [401] * 5 + [429]
                self.result(name, statuses, 'rate_limited' if ok else 'unexpected',
                    '백엔드가 5회 실패 후 6번째 시도를 제한함.' if ok else '로그인 제한 응답을 확인하세요.')
            elif name == 'staff_access':
                status, _ = self.call('/api/staff/customers', token=token)
                self.result(name, [status], 'blocked' if status == 403 else 'allowed' if status == 200 else 'unexpected',
                    '일반 고객 토큰으로 직원 전용 API에 요청한 결과.')
            elif name == 'idor':
                status, data = self.call(f'/api/customers/{target_id}', token=token)
                outcome = 'blocked' if status == 403 else (
                    'allowed' if status == 200 and isinstance(data, dict) and data.get('customer_id') == target_id else 'unexpected')
                self.result(name, [status], outcome,
                    '다른 실습 고객 조회: fixed는 403, vulnerable은 대상 정보가 포함된 200을 반환함.')
            else:
                self.stage = 'setup'
                pin = f'{secrets.randbelow(10000):04d}'
                source = self.expect('/api/accounts', {'account_pin': pin}, target_token, status=201)
                destination = self.expect('/api/accounts', {'account_pin': pin}, token, status=201)
                for account in (source, destination):
                    if type(account.get('account_id')) is not int or account['account_id'] <= 0:
                        raise ValueError('계좌 생성 응답에 계좌 ID가 없습니다.')
                self.stage = name
                status, _ = self.call('/api/transfers', {'from_account': source['account_id'],
                    'to_account': destination['account_id'], 'amount': 1, 'account_pin': pin,
                    'request_id': str(uuid4())}, token)
                self.result(name, [status], 'blocked' if status == 403 else 'unexpected',
                    '다른 실습 고객의 출금 계좌에 대한 소유권 검사. 새 계좌는 잔액 0이며 충전하지 않음.')


def save_report(runner, folder, error):
    folder.mkdir(parents=True, exist_ok=True)
    run_id = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ') + '-' + uuid4().hex[:8]
    data = {'run_id': run_id, 'runner': 'python', 'base_url': runner.base_url,
            'completed': error is None, 'error': error, 'results': runner.results, 'requests': runner.events,
            'enforcement_source': 'backend_rules', 'blue_executed': False}
    destination = folder / f'red_{run_id}.json'
    destination.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    esc = lambda v: html.escape(str(v))
    rows = ''.join('<tr>' + ''.join(f'<td>{esc(v)}</td>' for v in
        (LABELS[r['scenario']], r['statuses'], r['outcome'], r['note'])) + '</tr>' for r in runner.results)
    requests = ''.join('<tr>' + ''.join(f'<td>{esc(v)}</td>' for v in
        (r['scenario'], r['method'], r['path'], r['status'], r['audit_persisted'], r['request_id'])) + '</tr>' for r in runner.events)
    report = destination.with_suffix('.html')
    report.write_text('<!doctype html><html lang="ko"><meta charset="utf-8"><title>FinLab Red 결과</title>'
        '<style>body{font-family:system-ui;margin:32px}table{border-collapse:collapse;width:100%}'
        'td,th{border:1px solid #ddd;padding:10px;text-align:left}th{background:#eee}</style>'
        '<h1>파이썬 Red 실행 결과</h1><p>실제 HTTP 요청 결과입니다. 차단 주체는 백엔드 규칙이며 Blue LLM은 실행하지 않았습니다.</p>'
        f'<p>{esc(error or "시나리오 요청 완료")}</p><table><tr><th>시나리오</th><th>HTTP</th><th>결과</th><th>설명</th></tr>{rows}</table>'
        '<h2>요청 기록</h2><p>audit=True는 서버가 감사 로그 저장을 확인했다는 뜻입니다. 비밀번호·토큰·응답 본문은 저장하지 않습니다.</p>'
        f'<table><tr><th>단계</th><th>메서드</th><th>경로</th><th>HTTP</th><th>audit</th><th>요청 ID</th></tr>{requests}</table></html>', encoding='utf-8')
    print(f'레드 JSON: {destination}\n레드 결과 화면: {report}', flush=True)
    return destination


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--base-url', default='http://127.0.0.1:8081')
    parser.add_argument('--scenario', choices=('all',) + SCENARIOS, default='all')
    parser.add_argument('--report-dir', type=Path, default=Path(__file__).resolve().parents[1] / 'logs')
    args = parser.parse_args(argv)
    try:
        runner = Runner(args.base_url)
    except ValueError as error:
        parser.error(str(error))
    error = None
    try:
        runner.execute(args.scenario)
    except (ValueError, OSError) as exc:
        error = str(exc)
        print(f'레드 실행 중단: {error}', file=sys.stderr)
    save_report(runner, args.report_dir, error)
    if runner.events and not all(e['audit_persisted'] for e in runner.events):
        print('주의: 일부 요청의 서버 감사 로그 저장을 확인하지 못했습니다.', file=sys.stderr)
        return 2
    return 2 if error or any(r['outcome'] == 'unexpected' or
        (r['scenario'] == 'staff_access' and r['outcome'] == 'allowed') for r in runner.results) else 0


if __name__ == '__main__':
    raise SystemExit(main())
