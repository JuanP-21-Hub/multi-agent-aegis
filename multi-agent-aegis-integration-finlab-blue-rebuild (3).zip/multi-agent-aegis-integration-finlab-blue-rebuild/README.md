# A2D 은행 · FinLab Blue 통합

## 파이썬 Red 연결 (추가)

현재 Red는 Python 시나리오 실행기입니다. LM Studio나 별도 Red LLM은 필요하지 않습니다.
기존 폴더에 적용할 때는 이 압축의 `banking/lab.py`와 `banking/red` 폴더를 기존 `banking`에 복사하세요.
기존 `.env`와 DB 볼륨은 유지합니다. 실행 중인 은행에 Python 코드만 연결하므로 Red 추가 때문에 Docker를 재빌드할 필요는 없습니다.

은행이 실행 중인 상태에서 기존 `banking` 폴더의 PowerShell에서:

```powershell
python .\lab.py red
explorer .\logs
```

기존 시작 시 `-p`, `--env-file`, `-f`를 사용했다면 red 앞에도 같은 옵션을 사용하세요.
공개 포트는 실행 중인 Compose에서 확인합니다. 주소를 직접 지정할 수도 있습니다:

```powershell
python .\lab.py red --base-url http://127.0.0.1:8081
```

매번 실습 고객 2명과 잔액 0인 계좌 2개를 자동 생성합니다. 기존 가입 계정의 비밀번호를 입력할 필요가 없습니다.
생성한 실습 데이터는 감사 기록 확인을 위해 DB에 남습니다. 실제 사용자 계정이나 기존 잔액은 사용하지 않습니다.

| 실행 시나리오 | 실제 요청 | 기본 백엔드의 예상 결과 |
| --- | --- | --- |
| 로그인 연속 실패 | 실습 고객에 잘못된 비밀번호 6회 | 401 다섯 번 → 429 |
| 직원 전용 접근 | 고객 토큰으로 GET /api/staff/customers | 403 |
| IDOR | 다른 실습 고객의 GET /api/customers/{id} | fixed: 403 / vulnerable: 200 |
| 송금 권한 검사 | 다른 실습 고객의 출금 계좌로 POST /api/transfers | 403 |

하나만 실행하려면 `--scenario login_failures`, `staff_access`, `idor`, `transfer` 중 하나를 지정합니다.
예: `python .\lab.py red --scenario staff_access`.
이 명령은 실제 직원 API 접근 요청을 보내며 웹 화면에 새 신청·승인 기능을 추가하지 않습니다.

결과는 `logs/red_실행번호.html`과 `.json`에 저장합니다. 서버 요청 ID와 감사 로그 저장 여부를 기록하고,
비밀번호·토큰·응답 본문은 결과 파일에 기록하지 않습니다. 서버에서 허용된 직원 계정으로 로그인하면
활동 로그에서도 요청을 확인할 수 있습니다.

HTTP 403/429 차단 주체는 기존 백엔드 규칙입니다. 이 작업으로 Blue 자동 방어가 추가되지는 않습니다.
`red`는 Blue를 호출하지 않으며, `run`은 기존대로 감사 로그 분석만 수행합니다.
필요하면 Red 종료 후 기존 `python .\lab.py run`으로 Blue 분석을 실행하세요.
기존 `run --scenario staff_access`는 여전히 합성 로그 재생입니다.

Red 종료 코드: 0은 시나리오 실행 완료, 2는 연결·준비·감사 로그 저장 확인 실패 또는 예상 밖 응답입니다.
IDOR에서 200은 다른 테스트 고객의 ID가 응답과 일치할 때만 허용 결과로 기록합니다.
송금은 권한 검사를 확인하며, 잔액을 충전하지 않으므로 권한이 허술할 때 실제 이체 성공까지 검증하지는 않습니다.

검증: 모의 HTTP 서버에서 Red 테스트 7개를 통과했습니다. 실제 Docker/PostgreSQL 환경은 이번 작업 환경에 없어 검증하지 못했습니다.


A2D 은행의 Nginx 화면, FastAPI와 PostgreSQL은 Docker Desktop에서 실행합니다. PowerShell에서 은행의 감사 로그를 읽고, LM Studio 또는 Runpod의 gpt-oss-20b로 분석합니다. 실행마다 브라우저에서 열 수 있는 HTML 보고서와 Streamlit 결과 JSON이 저장됩니다.

## 내 컴퓨터에서 실행

이 압축 파일의 `banking/.env`에는 업로드한 핀랩 블루의 DB 비밀번호와 암호화 키가 들어 있습니다. 멀티 환경에 맞게 `LAB_MODE=fixed`, `WEB_PORT=8081`을 설정했습니다.

Docker Desktop을 켜고, LM Studio에서 GPT-OSS 모델과 로컬 서버를 시작합니다. `banking` 폴더에서 PowerShell을 열고 실행합니다.

~~~powershell
$env:FINLAB_BLUE_BASE_URL = 'http://127.0.0.1:1234/v1'
$env:FINLAB_BLUE_MODEL = 'auto-gpt-oss'
python .\lab.py start
~~~

은행은 http://127.0.0.1:8081 에서 열립니다. 로그인이나 계좌 조회 후 같은 창에서 `python .\lab.py run`을 실행하면 블루가 최근 감사 로그를 분석합니다.

### 이번 설정 수정의 검증 범위

필수 Compose 변수 3개가 모두 채워져 있고, 핀랩 블루의 키와 일치하며, 암호화 키가 유효한 형식인지 확인했습니다. Docker와 실제 PostgreSQL 기동은 이 작업 환경에서 검증하지 못했습니다.

## 1. 팀원 실행 방법

### 이 PC에서 은행을 이미 실행한 경우

기존 은행 폴더의 설정 파일, 암호화 키, Compose 프로젝트 이름과 DB 볼륨을 사용합니다. 기존 Windows 시작 파일로 은행을 띄웠다면 같은 작업 폴더에서 새 코드를 적용하고, 이전 시작 명령에 사용한 프로젝트 이름과 설정 파일을 아래 명령에도 지정합니다.

~~~powershell
cd .\banking
docker compose ls
$Project = Read-Host '기존 은행 Compose 프로젝트 이름'
python .\lab.py -p $Project start
~~~

기존 명령에 환경 파일 또는 추가 Compose 파일이 있었다면 동일하게 전달합니다. 아래 예는 외부에 이미 있는 DB 볼륨을 쓰는 경우입니다.

~~~powershell
python .\lab.py -p $Project --env-file .\.env -f .\compose.existing.yaml start
~~~

위에 지정한 옵션은 이후 로그 조회, 분석, 중지에도 동일하게 사용합니다. 외부 볼륨을 쓰는 경우 기존 설정의 BANK_DATA_VOLUME 이름과 DB 암호화 키를 보존하세요.

### 팀원이 처음 실행하는 경우

Docker Desktop과 Python 3.12 이상을 설치합니다. 이 압축 파일에는 실행 설정이 포함되어 있으므로 위의 로컬 실행 명령을 사용할 수 있습니다. 별도 신규 프로젝트에서 .env가 없는 경우에만 banking 폴더의 WSL2 Ubuntu 터미널에서 다음 명령으로 설정을 생성합니다.

~~~bash
bash scripts/init-env.sh
~~~

Windows 탐색기로 같은 banking 폴더를 열고, 주소창에서 powershell을 실행합니다. Python이 PATH에 없다면 아래의 python 대신 설치된 python.exe를 사용합니다.

~~~powershell
python .\lab.py start
Invoke-RestMethod http://127.0.0.1:8081/api/health/db
~~~

banking 폴더가 WSL의 Linux 파일 시스템에 있다면 설정 생성과 은행 시작을 같은 WSL 또는 Docker Desktop 파일 공유 환경에서 진행하세요. 기본 은행 주소는 http://127.0.0.1:8081입니다. .env에 WEB_PORT가 설정된 환경에서는 그 포트를 사용합니다.

## 2. 테스트 계정과 은행 사용

- 고객은 은행 화면에서 가상 주민번호 형식으로 가입하고, 로그인한 뒤 모의 계좌를 만듭니다.
- 직원과 관리자는 같은 Compose 프로젝트의 백엔드 컨테이너에서 생성합니다. 기존 프로젝트에 -p 옵션을 썼다면 아래 명령에도 붙입니다. 비밀번호는 실행 중에 직접 입력합니다.

~~~powershell
docker compose exec backend python -m app.create_staff
docker compose exec backend python -m app.create_staff --role ADMIN
~~~

직원 화면의 **활동 로그**는 요청과 권한 검사 결과를 보여줍니다. 관리자에게는 역할이 요구된 요청만 모아 보는 **보안 기록** 메뉴도 표시됩니다. 고객 화면에서는 본인 계좌만 거래 내역을 확인하고, 계좌 비밀번호를 입력해 모의 이체를 할 수 있습니다. 기존 잔액이 0원인 테스트 계좌는 Docker 운영자가 아래처럼 모의 자금을 준비한 뒤 이체를 확인합니다.

~~~powershell
docker compose exec backend python -m app.fund_demo 1 10000
~~~

위 명령의 1은 테스트 화면에 표시되는 출금 계좌 ID입니다. 이체는 잔액과 양쪽 거래 기록을 한 DB 트랜잭션으로 저장합니다. 동일한 요청 ID와 이체 내용을 재전송하면 이전 결과를 반환합니다.

## 3. Runpod 연결

Runpod Pod에서 vLLM으로 openai/gpt-oss-20b를 Pod 내부의 127.0.0.1:8000에 실행합니다. Pod에 접속하는 PowerShell에서 SSH 포트 포워딩 옵션을 추가합니다. HOST와 PORT는 Runpod의 Direct TCP ports에 표시된 값으로 바꿉니다.

~~~powershell
ssh -i "$env:USERPROFILE\.ssh\id_ed25519" -p PORT -L 127.0.0.1:18000:127.0.0.1:8000 root@HOST
~~~

새 Pod라면 SSH로 접속한 Linux 터미널에서 모델 서버를 준비합니다. 앞서 사용한 RTX A5000 테스트는 vLLM 0.34.0, 컨텍스트 8,192토큰, 동시 요청 1개로 구동했습니다.

~~~bash
uv venv /opt/finlab-vllm/venv
uv pip install --python /opt/finlab-vllm/venv/bin/python 'vllm==0.34.0' --torch-backend=auto
/opt/finlab-vllm/venv/bin/vllm serve openai/gpt-oss-20b --host 127.0.0.1 --port 8000 --max-model-len 8192 --max-num-seqs 1 --enforce-eager
~~~

SSH 창을 켜 둔 채, **banking 폴더를 연 별도의 Windows PowerShell**에서 실행합니다.

~~~powershell
(Invoke-RestMethod http://127.0.0.1:18000/v1/models).data.id
$env:FINLAB_BLUE_BASE_URL = 'http://127.0.0.1:18000/v1'
$env:FINLAB_BLUE_MODEL = 'openai/gpt-oss-20b'
~~~

## 4. 시연 순서와 결과 확인

1. 은행 화면에서 정상 테스트 로그인, 계좌 조회 또는 직원 조회를 진행합니다.
2. 아래 순서대로 감사 로그를 확인하고 Blue 분석을 실행합니다. 기존 Compose 옵션을 쓰는 PC에서는 동일한 옵션을 logs와 run 앞에 넣습니다.

~~~powershell
python .\lab.py logs
Get-Content .\logs\security.jsonl -Tail 10
python .\lab.py run
explorer .\logs
~~~

- 기본 run은 Docker 은행의 최근 감사 로그를 읽고, 모델 ID와 묶음별 판정을 PowerShell에 출력합니다. HTML은 logs/report_실행번호.html에 생성됩니다. 보고서에는 권한 정책 대조, Blue 판정과 권고, 실제 역할·필요 역할·판정이 담긴 근거 로그가 나옵니다.
- 보유한 감사 로그는 python .\lab.py run --log 경로 로 읽을 수 있습니다.
- python .\lab.py run --scenario staff_access 는 저장된 합성 로그로 직원 역할 판정의 예시를 재생하며, 보고서에 합성 데이터가 표시됩니다. 기본 검사만 확인할 때는 --baseline-only 를 붙입니다.
- 런타임 모델 입력은 요청 메서드, 경로 템플릿, 상태, 역할, 권한 판정 등 정규화된 감사 항목입니다. DB 내 사용자 식별자와 HTTP 본문은 전송 범위에서 제외됩니다.

### Streamlit에서 같은 실행 확인

~~~powershell
cd .\blue\dashboard
python -m pip install -r requirements.txt
python -m streamlit run app.py --server.address 127.0.0.1
~~~

http://127.0.0.1:8501에서 **실제 결과 파일**을 고른 다음 해당 실행을 선택합니다. 결과 JSON은 blue/dashboard/runs/실행번호/evaluation.json에 저장됩니다. 탐지 비교, 대응 권고, 근거 및 평가 탭에서 같은 실행을 볼 수 있습니다.

## 5. 중지와 기존 데이터

~~~powershell
python .\lab.py stop
~~~

기존 Compose 옵션을 사용한 경우 중지 명령에도 붙이세요. 중지는 컨테이너를 정지하고 DB 볼륨을 보존합니다. 기존 DB를 다른 PC로 옮길 경우 먼저 백업하고, 원래 .env와 암호화 키로 기존 볼륨을 연결한 다음 마이그레이션을 적용합니다. 002_finlab_blue.sql은 이체 요청 기록 테이블을 추가합니다.

## 6. 검증 범위

합성 로그의 기본 검사와 모의 모델 응답으로 JSON·HTML 생성 및 로그 필터를 검증합니다. 운영 환경에서는 DB 연결 확인, 테스트 로그인·조회, Runpod 모델 ID, HTML의 로그 행을 순서대로 확인하세요.

## 7. 핀랩 블루 시나리오 백엔드

고객과 직원 로그인은 각각 같은 아이디에서 60초 동안 인증이 5번 실패하면 그다음 요청에 HTTP 429와 `Retry-After`(초)를 반환합니다. 제한 전에 로그인에 성공하면 해당 아이디의 실패 횟수가 초기화됩니다. 횟수는 현재 백엔드 프로세스에 저장됩니다. 직원 또는 관리자 로그인으로 `GET /api/lab/status`를 조회하면 적용 중인 제한과 판정 주체를 확인할 수 있습니다.

관리자 화면의 **보안 기록**에서 해당 요청의 HTTP 상태와 **로그인 시도 제한**을 확인할 수 있습니다. 기존 Compose 설정으로 은행을 시작한 뒤 `banking`에서 `python .\lab.py run --baseline-only`를 실행하면 실제 감사 로그로 HTML을 생성합니다. 이전에 사용한 프로젝트 이름, 환경 파일, 추가 Compose 파일을 동일하게 지정하세요.

직원 전용 고객 조회와 본인 계좌 거래내역 조회는 멀티의 권한 검사를 사용합니다. 거래내역 응답은 멀티용 `items`와 핀랩용 `account_id`, `transactions`를 함께 반환합니다. 모의 송금은 기존 `POST /api/transfers`에서 처리합니다.
